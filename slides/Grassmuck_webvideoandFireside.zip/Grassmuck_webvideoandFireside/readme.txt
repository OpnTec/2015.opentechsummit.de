﻿Readme für Grassmuck_webvideoandFireside


Hi,
keine Folien. Die Idee ist, dass ich die 8 Links in dem beiliegenden Text zeigen möchte. Kann ich mir in einer Pause in nem Browser-Fenster in Tabs nebeneinander klicken.

Die Idee ist ferner, am Schluss per Fireside / WebRTC Jamie aus Puerto Rico (?) dazu zu holen. Wenn wir die Session mit Fireside aufnehmen wollen, müsste das ein Firefox Nightly sein. Wenn nicht, geht jeder WebRTC-fähige HTML5-Browser.

Als Backup, falls live online nicht funktioniert, anbei ein Screenshot und ein WebM von unserer allerersten Session. Bitte mal testen, ob das WebM läuft. 

Danke!

Volker

